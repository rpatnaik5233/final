package com.capgemini.cabdemo.dao;

import com.capgemini.cabdemo.bean.CustomerBean;
import com.capgemini.cabdemo.exception.CabException;

public interface ICustomerDAO {

	public boolean insertCustomer(CustomerBean customerBean) throws CabException;
	
	public int viewCabs(String pin) throws CabException;
	
	public int getID() throws CabException; 
	
}
