package com.capgemini.cabdemo.exception;

public class CabException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8855321909194860207L;
public CabException()
{
	super();
}
public CabException(String message)
{
	super(message);
}
}
