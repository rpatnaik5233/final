package com.capgemini.employeeapplication.test;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.employeeapplication.bean.EmployeeBean;
import com.capgemini.employeeapplication.exception.EmployeeException;
import com.capgemini.employeeapplication.service.EmployeeServiceImpl;
import com.capgemini.employeeapplication.service.IEmployeeService;

public class EmployeeServiceImplTest {
	EmployeeBean emp= new EmployeeBean();
	@Before
	public void setUp() throws Exception {
	emp=new EmployeeBean("Abc","HR", 1234, "10/10/2017");
	}

	@After
	public void tearDown() throws Exception {
	emp=null;
	}

	@Test
	public final void test() {
		IEmployeeService serviceEmployee = new EmployeeServiceImpl();
		try
		{
		assertTrue(serviceEmployee.addEmployeeDetails(emp)); 
		}
		catch(EmployeeException e){
			e.printStackTrace();
		}
	}

}
