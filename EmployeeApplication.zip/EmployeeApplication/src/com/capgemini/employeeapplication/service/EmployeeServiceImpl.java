package com.capgemini.employeeapplication.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.employeeapplication.bean.EmployeeBean;
import com.capgemini.employeeapplication.dao.EmployeeDAOImpl;
import com.capgemini.employeeapplication.dao.IEmployeeDAO;
import com.capgemini.employeeapplication.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {

	@Override
	public boolean addEmployeeDetails(EmployeeBean emp) throws EmployeeException {
		boolean isItInserted=false;
		IEmployeeDAO employeedao= new EmployeeDAOImpl();
		isItInserted=employeedao.addEmployeeDetails(emp);
			return isItInserted;
	}
	
	@Override
	public boolean updateDetails(int empId, float salary) {
		boolean isItUpdated=false;
		IEmployeeDAO employeedao= new EmployeeDAOImpl();
		try {
			isItUpdated=employeedao.updateDetails(empId, salary);
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
		return isItUpdated;
	}

	@Override
	public boolean delete(int empId) {
	boolean isDeleted=false;
	IEmployeeDAO employeedao= new EmployeeDAOImpl();
	try {
		isDeleted=employeedao.delete(empId);
	} catch (EmployeeException e) {
				e.printStackTrace();
	}
	return isDeleted;
	
	}

	public boolean isValidEName(String ename) throws EmployeeException{
		boolean isValid=false;
		String pattern="[A-Z]{1}[A-za-z]{1,19}";
		Pattern ptn=Pattern.compile(pattern);
		Matcher matcher =ptn.matcher(ename);
		isValid=matcher.matches();
		if(!isValid)
		{
			throw new EmployeeException("Invalid Name.");
		}
		return isValid;
	}
	
	public boolean isValidSalary(float salary) throws EmployeeException{
		boolean isValid=false;
		if(salary<=0)
		{
			throw new EmployeeException("Salary cannot be 0");
		}
		else
		{
			isValid=true;
		}
		return isValid;
	}

	
	}
	
