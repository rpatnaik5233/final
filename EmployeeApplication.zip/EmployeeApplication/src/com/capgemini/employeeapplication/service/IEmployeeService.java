package com.capgemini.employeeapplication.service;

import com.capgemini.employeeapplication.bean.EmployeeBean;
import com.capgemini.employeeapplication.exception.EmployeeException;

public interface IEmployeeService {

	public boolean addEmployeeDetails(EmployeeBean emp) throws EmployeeException;
	public boolean updateDetails(final int empId,final float salary);
	public boolean delete(final int empId);
	
}
