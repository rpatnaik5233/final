package com.capgemini.employeeapplication.dao;

public interface QueryMapper {

	public static final String INSERT_QUERY="INSERT INTO employee VALUES(employee_sequence.NEXTVAL,?,?,?,?)";
	public static final String UPDATE_QUERY="UPDATE employee SET salary=? WHERE Employee_Id=?";
	public static final String DELETE_QUERY="DELETE FROM employee WHERE Employee_Id=?";

}
