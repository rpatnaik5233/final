package com.capgemini.employeeapplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Scanner;

import com.capgemini.employeeapplication.bean.EmployeeBean;
import com.capgemini.employeeapplication.exception.EmployeeException;
import com.capgemini.employeeapplication.util.DBConnection;


public class EmployeeDAOImpl implements IEmployeeDAO {
	boolean isInserted=false;
	Scanner scInput = new Scanner(System.in);
		@Override
	public boolean addEmployeeDetails(EmployeeBean emp) throws EmployeeException {

		int records=0;
		boolean isInserted=false;
try(Connection connEmployeeDetails = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=
				connEmployeeDetails.prepareStatement(QueryMapper.INSERT_QUERY);
		)
		{
	DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
	

	
	TemporalAccessor ta = dtf.parse(emp.getHireDate());
	
	LocalDate localDate= LocalDate.from(ta);
	
	java.sql.Date translatedDate=java.sql.Date.valueOf(localDate);
	preparedStatement.setString(1,emp.getName());
	preparedStatement.setFloat(2, emp.getSalary());
	preparedStatement.setString(3, emp.getDepartment());
	preparedStatement.setDate(4, translatedDate);
	records=preparedStatement.executeUpdate();
	if(records>0)
	{
		isInserted=true;
	}
		}catch(SQLException sqlEx)
{
			throw new EmployeeException(sqlEx.getMessage());
}
		return isInserted;		
		}
	@Override
	public boolean updateDetails(int empId, float salary)
			throws EmployeeException {
		int records=0;
		boolean isUpdated=false;
try(Connection connEmployeeDetails = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=
				connEmployeeDetails.prepareStatement(QueryMapper.UPDATE_QUERY);
		)
		{
		preparedStatement.setFloat(1, empId);
		preparedStatement.setFloat(2, salary);
		records=preparedStatement.executeUpdate();
	if(records>0)
	{
		isUpdated=true;
	}
		}catch(SQLException sqlEx)
{
			throw new EmployeeException(sqlEx.getMessage());
}
		return isUpdated;		
			}
	@Override
	public boolean delete(int empId) throws EmployeeException {
		int records=0;
		boolean isDeleted=false;
try(Connection connEmployeeDetails = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=
				connEmployeeDetails.prepareStatement(QueryMapper.DELETE_QUERY);
		)
		{
		preparedStatement.setInt(1, empId);
		records=preparedStatement.executeUpdate();
	if(records>0)
	{
		isDeleted=true;
	}
		}catch(SQLException sqlEx)
{
			throw new EmployeeException(sqlEx.getMessage());
}
		return isDeleted;
		}
}
