package com.capgemini.employeeapplication.dao;

import com.capgemini.employeeapplication.bean.EmployeeBean;
import com.capgemini.employeeapplication.exception.EmployeeException;


public interface IEmployeeDAO {

	public boolean addEmployeeDetails(EmployeeBean emp) throws EmployeeException;
	public boolean updateDetails(final int empId,final float salary) throws EmployeeException;
	public boolean delete(final int empId) throws EmployeeException;
}

