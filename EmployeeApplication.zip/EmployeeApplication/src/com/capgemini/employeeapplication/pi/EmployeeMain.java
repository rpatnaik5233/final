package com.capgemini.employeeapplication.pi;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.employeeapplication.bean.EmployeeBean;
import com.capgemini.employeeapplication.exception.EmployeeException;
import com.capgemini.employeeapplication.service.EmployeeServiceImpl;

public class EmployeeMain {
	private static Logger logger=Logger.getRootLogger();
	public static void main(String[] args) {		
		PropertyConfigurator.configure("resources/log4j.properties");
		boolean isInProcess=true;
		boolean isValid=false;
		byte choice=0; 
		String ename=null;
		float salary=0;
		String department=null;
		String date=null;
		EmployeeBean emp=null;
		EmployeeServiceImpl employeeServiceImpl= new EmployeeServiceImpl();
		Scanner sc=new Scanner(System.in);
		while(isInProcess)
		{
			System.out.println("1) Insert data into Employee.");
			System.out.println("2) Update Employee Data.");
			System.out.println("3) Delete Employee Data.");
			System.out.println("0) Exit.");
			
			choice=sc.nextByte();
			sc.nextLine();
			switch(choice){
			
			case 1:
				isValid=false;
				while(!isValid){
					try
					{
						System.out.println("Enter Employee Name: ");
						ename=sc.nextLine();
						isValid= employeeServiceImpl.isValidEName(ename);
					}catch(EmployeeException e){
						logger.error("Invalid name: "+ename);
						System.err.println("Invalid name: "+ename);
						isValid=false;
					}
				}
				isValid=false;
				while(!isValid){
					try
					{
						System.out.println("Enter salary: ");
						salary=Float.parseFloat(sc.nextLine());
						isValid= employeeServiceImpl.isValidSalary(salary);
					}catch(EmployeeException e){
						logger.error("Invalid salary: "+salary);
						System.err.println("Invalid : "+salary);
						isValid=false;
					}
				}
				System.out.println("Enter Date of Joining in DD/MM/YYYY format: ");
				date=sc.nextLine();
						
				System.out.println("Enter Department Name: ");
				department=sc.nextLine();
				emp=new EmployeeBean(ename, department, salary, date);
				try
				{
					boolean isInserted=employeeServiceImpl.addEmployeeDetails(emp);
					if(isInserted)
					{
						System.out.println("Inserted Successfully");
					}
				}catch(EmployeeException e)
				{
					logger.error(e.getMessage());
				}
				break;
			case 2:
				boolean isUpdated=false;
				System.out.println("Enter Employee Id: ");
				int empId=Integer.parseInt(sc.nextLine());
				System.out.println("Enter Salary: ");
				salary=sc.nextFloat();
				try{
					isUpdated=employeeServiceImpl.updateDetails(empId, salary);
					if(isUpdated)
						System.out.println("Salary Successfully Updated.");
					else
						throw new EmployeeException("Invalid");
				}catch(EmployeeException e)
				{
					logger.error(e.getMessage());
				}
				break;
			case 3:
				boolean isDeleted=false;
				System.out.println("Enter Employee Id: ");
				empId=Integer.parseInt(sc.nextLine());
				try
				{
					isDeleted=employeeServiceImpl.delete(empId);
					if(isDeleted)
					{
						System.out.println("Deleted Succcessfully");
					}
					
					else
						throw new EmployeeException("Invalid");
				}catch(EmployeeException e)
				{
					logger.error(e.getMessage());
				}
				break;
			case 0:
				isInProcess=false;
				break;
				default:
					System.out.println("Invalid Choice"+choice);
					logger.error("Invalid input: "+choice);
					break;
			}
		
		}
		sc.close();	
	}

}
