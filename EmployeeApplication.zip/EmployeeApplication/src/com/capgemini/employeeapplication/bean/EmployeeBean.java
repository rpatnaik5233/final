package com.capgemini.employeeapplication.bean;


public class EmployeeBean {

	private int empId;
	private String name;
	private String department;
	private float salary;
	private String hireDate; 
	public EmployeeBean() {
		super();
	}
	public EmployeeBean(String name, String department, float salary, String date) {
		super();
		this.name = name;
		this.department = department;
		this.salary = salary;
		this.hireDate=date;
	}
		
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getHireDate() {
		return hireDate;
	}
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}
	@Override
	public String toString() {
		return "EmployeeBean [empId=" + empId + ", name=" + name + ", department=" + department + ", salary=" + salary
				+ ", hireDate=" + hireDate + "]";
	}

	
	
	
}
